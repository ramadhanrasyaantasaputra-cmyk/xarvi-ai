import { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  ArrowDownRight,
  ArrowRight,
  BookOpen,
  Bot,
  BrainCircuit,
  ChevronRight,
  Code2,
  FileText,
  Github,
  LayoutDashboard,
  Menu,
  MessageSquare,
  Plus,
  Send,
  Settings,
  ShieldCheck,
  Sparkles,
  Trash2,
  X,
  Zap,
} from 'lucide-react';

type View = 'Home' | 'Workspace' | 'Dashboard' | 'Settings';
type ChatMessage = { id: string; role: 'user' | 'assistant'; content: string; createdAt: string };

const initialMessages: ChatMessage[] = [];
const storageKey = 'xarvi-ai-demo-messages-v1';

const tools = [
  { name: 'AI Writer', description: 'Bantu menyusun ide dan tulisan.', icon: FileText, prompt: 'Bantu saya membuat kerangka tulisan tentang teknologi AI untuk pelajar.' },
  { name: 'Study Assistant', description: 'Pahami materi dengan lebih terarah.', icon: BookOpen, prompt: 'Jelaskan cara belajar topik yang sulit secara bertahap.' },
  { name: 'Code Assistant', description: 'Pelajari konsep coding dengan contoh.', icon: Code2, prompt: 'Jelaskan konsep dasar JavaScript kepada pemula dengan contoh sederhana.' },
  { name: 'Idea Generator', description: 'Kembangkan ide menjadi rencana.', icon: Sparkles, prompt: 'Berikan tiga ide proyek teknologi yang realistis untuk pemula.' },
];

function readMessages(): ChatMessage[] {
  try {
    const saved = localStorage.getItem(storageKey);
    if (!saved) return initialMessages;
    const parsed: unknown = JSON.parse(saved);
    if (!Array.isArray(parsed)) return initialMessages;
    return parsed.filter((item): item is ChatMessage =>
      item && typeof item.id === 'string' &&
      (item.role === 'user' || item.role === 'assistant') &&
      typeof item.content === 'string' && typeof item.createdAt === 'string'
    );
  } catch {
    return initialMessages;
  }
}

function demoReply(prompt: string): string {
  const clean = prompt.trim();
  return `Ini adalah respons demo XARVI AI, bukan jawaban dari model AI sungguhan.\n\nUntuk mengembangkan ide “${clean.slice(0, 180)}${clean.length > 180 ? '…' : ''}”, kamu bisa mulai dengan langkah berikut:\n\n1. Tentukan tujuan yang ingin dicapai.\n2. Pecah tujuan menjadi tugas kecil yang bisa diuji.\n3. Kerjakan satu langkah terlebih dahulu, lalu evaluasi hasilnya.\n\nPada milestone berikutnya, respons ini akan diganti dengan respons dari API AI melalui backend yang aman.`;
}

function App() {
  const [view, setView] = useState<View>('Home');
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>(readMessages);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState('');
  const [language, setLanguage] = useState('Bahasa Indonesia');
  const [theme, setTheme] = useState('Dark');

  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(messages));
    } catch {
      setNotice('Riwayat tidak dapat disimpan di browser ini.');
    }
  }, [messages]);

  useEffect(() => {
    document.documentElement.dataset.theme = theme.toLowerCase();
  }, [theme]);

  const navItems = useMemo(() => [
    { label: 'Home' as const, icon: Sparkles },
    { label: 'Workspace' as const, icon: MessageSquare },
    { label: 'Dashboard' as const, icon: LayoutDashboard },
    { label: 'Settings' as const, icon: Settings },
  ], []);

  function navigate(next: View) {
    setView(next);
    setMobileNavOpen(false);
    setNotice('');
  }

  function startNewChat() {
    setMessages([]);
    setPrompt('');
    setNotice('Percakapan baru dimulai. Mode saat ini masih demo.');
    setView('Workspace');
    setMobileNavOpen(false);
  }

  function sendMessage(text = prompt) {
    const content = text.trim();
    if (!content || busy) return;
    const userMessage: ChatMessage = {
      id: crypto.randomUUID(), role: 'user', content, createdAt: new Date().toISOString(),
    };
    setMessages((current) => [...current, userMessage]);
    setPrompt('');
    setBusy(true);
    setNotice('');
    setView('Workspace');
    // Deliberately local demo behavior. No network request or API key is used in Milestone 1.
    window.setTimeout(() => {
      const assistantMessage: ChatMessage = {
        id: crypto.randomUUID(), role: 'assistant', content: demoReply(content), createdAt: new Date().toISOString(),
      };
      setMessages((current) => [...current, assistantMessage]);
      setBusy(false);
    }, 550);
  }

  const pageTitle = view === 'Home' ? 'Your AI workspace' : view === 'Workspace' ? 'AI Workspace' : view;

  return (
    <div className="app-shell">
      {mobileNavOpen && <button className="mobile-scrim" aria-label="Tutup navigasi" onClick={() => setMobileNavOpen(false)} />}
      <aside className={`sidebar ${mobileNavOpen ? 'sidebar-open' : ''}`}>
        <div className="brand-lockup">
          <span className="brand-mark"><BrainCircuit size={22} /></span>
          <span className="brand-copy"><strong>XARVI<span> AI</span></strong><small>INTELLIGENT WORKSPACE</small></span>
          <button className="sidebar-close" aria-label="Tutup menu" onClick={() => setMobileNavOpen(false)}><X size={18} /></button>
        </div>

        <button className="new-chat-button" onClick={startNewChat}><Plus size={17} /> New conversation</button>
        <p className="nav-label">WORKSPACE</p>
        <nav className="main-nav" aria-label="Navigasi utama">
          {navItems.map(({ label, icon: Icon }) => (
            <button key={label} className={`nav-item ${view === label ? 'active' : ''}`} onClick={() => navigate(label)}>
              <Icon size={18} strokeWidth={1.8} /><span>{label === 'Home' ? 'Home' : label === 'Workspace' ? 'AI Workspace' : label}</span>
              {view === label && <span className="nav-active-dot" />}
            </button>
          ))}
        </nav>

        <p className="nav-label tools-label">AI TOOLS <span className="tiny-badge">BETA</span></p>
        <div className="tool-nav">
          {tools.map(({ name, icon: Icon, prompt: toolPrompt }) => (
            <button key={name} className="nav-item" onClick={() => { setPrompt(toolPrompt); navigate('Workspace'); }}>
              <Icon size={17} strokeWidth={1.8} /><span>{name}</span>
            </button>
          ))}
        </div>

        <div className="sidebar-bottom">
          <div className="privacy-mini"><ShieldCheck size={17} /><span><strong>Privacy first</strong><small>Demo mode · No AI API calls</small></span></div>
          <a className="github-link" href="https://github.com" target="_blank" rel="noreferrer"><Github size={16} /> GitHub <ArrowRight size={14} /></a>
          <div className="user-chip"><div className="avatar">X</div><span><strong>XARVI Creator</strong><small>Starter workspace</small></span><span className="online-dot" /></div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="topbar-left">
            <button className="icon-button mobile-menu" aria-label="Buka navigasi" onClick={() => setMobileNavOpen(true)}><Menu size={20} /></button>
            <div className="breadcrumb"><span>Workspace</span><ChevronRight size={14} /><strong>{pageTitle}</strong></div>
          </div>
          <div className="topbar-right"><span className="status-pill"><span className="status-dot" /> Demo environment</span><div className="top-avatar">X</div></div>
        </header>

        {notice && <div className="notice-bar" role="status"><span>{notice}</span><button aria-label="Tutup notifikasi" onClick={() => setNotice('')}><X size={15} /></button></div>}

        {view === 'Home' && <HomeView onStart={() => navigate('Workspace')} onTool={(text) => { setPrompt(text); navigate('Workspace'); }} />}
        {view === 'Workspace' && <WorkspaceView messages={messages} prompt={prompt} busy={busy} setPrompt={setPrompt} onSend={sendMessage} onNew={startNewChat} />}
        {view === 'Dashboard' && <DashboardView messages={messages} onOpenWorkspace={() => navigate('Workspace')} onClear={() => { setMessages([]); setNotice('Riwayat lokal telah dihapus.'); }} />}
        {view === 'Settings' && <SettingsView language={language} setLanguage={setLanguage} theme={theme} setTheme={setTheme} onClear={() => { setMessages([]); setNotice('Riwayat lokal telah dihapus.'); }} />}

        <footer className="app-footer"><span>© 2026 XARVI AI · Built for curious minds.</span><span><span className="footer-dot" /> Prototype v0.1.0</span></footer>
      </main>
    </div>
  );
}

function HomeView({ onStart, onTool }: { onStart: () => void; onTool: (text: string) => void }) {
  return (
    <div className="page-content home-page">
      <section className="hero-panel">
        <div className="hero-orb orb-one" /><div className="hero-orb orb-two" /><div className="hero-grid" />
        <div className="hero-content">
          <div className="eyebrow"><span className="eyebrow-spark"><Sparkles size={13} /></span> A NEW WAY TO THINK <span className="eyebrow-line" /></div>
          <h1>Your ideas,<br />amplified by <span>intelligence.</span></h1>
          <p className="hero-description">Satu ruang kerja untuk mengeksplorasi ide, belajar lebih cepat, dan mengubah rasa ingin tahu menjadi sesuatu yang nyata.</p>
          <div className="hero-actions"><button className="primary-button" onClick={onStart}>Explore workspace <ArrowRight size={17} /></button><span className="hero-caption"><ShieldCheck size={15} /> Built with privacy in mind</span></div>
        </div>
        <div className="hero-visual" aria-hidden="true"><div className="visual-ring ring-a" /><div className="visual-ring ring-b" /><div className="visual-ring ring-c" /><div className="visual-core"><BrainCircuit size={47} strokeWidth={1.25} /></div><span className="orbit-chip chip-top"><Sparkles size={13} /> Intelligence</span><span className="orbit-chip chip-bottom"><Activity size={13} /> Possibility engine</span><span className="visual-cross cross-a">+</span><span className="visual-cross cross-b">+</span></div>
        <div className="hero-bottom"><span><span className="tiny-pulse" /> DESIGNED FOR CURIOSITY</span><span>01 / INTELLIGENT WORKSPACE</span></div>
      </section>

      <section className="section-block">
        <div className="section-heading"><div><span className="section-kicker">YOUR TOOLKIT</span><h2>One space. Many possibilities.</h2><p>Mulai dari ide sederhana hingga proses belajar yang lebih terstruktur.</p></div><button className="text-button" onClick={onStart}>Open workspace <ArrowRight size={15} /></button></div>
        <div className="tool-grid">
          {tools.map(({ name, description, icon: Icon, prompt }) => <button className="feature-card" key={name} onClick={() => onTool(prompt)}><span className="feature-icon"><Icon size={20} /></span><span className="feature-arrow"><ArrowDownRight size={17} /></span><strong>{name}</strong><span className="feature-description">{description}</span><span className="feature-bottom"><span className="feature-dot" /> Explore tool</span></button>)}
        </div>
      </section>

      <section className="bottom-banner"><div className="banner-icon"><Zap size={20} /></div><div><strong>Built to grow with your ideas.</strong><p>Ini adalah fondasi awal XARVI AI. Integrasi model AI sungguhan akan ditambahkan setelah backend aman siap.</p></div><button className="banner-button" onClick={onStart}>Try the demo <ArrowRight size={15} /></button></section>
    </div>
  );
}

function WorkspaceView({ messages, prompt, busy, setPrompt, onSend, onNew }: { messages: ChatMessage[]; prompt: string; busy: boolean; setPrompt: (value: string) => void; onSend: (text?: string) => void; onNew: () => void }) {
  return (
    <div className="page-content workspace-page">
      <div className="workspace-heading"><div><span className="section-kicker">YOUR THINKING SPACE</span><h1>What are we exploring?</h1><p>Tanyakan sesuatu, kembangkan ide, atau mulai dari salah satu tool.</p></div><button className="secondary-button" onClick={onNew}><Plus size={16} /> New chat</button></div>
      <div className="demo-warning"><span className="warning-icon"><Bot size={17} /></span><span><strong>Demo mode aktif.</strong> Balasan saat ini dibuat secara lokal, belum berasal dari model AI/API.</span></div>
      {messages.length === 0 ? <div className="empty-chat"><div className="empty-orb"><BrainCircuit size={32} /></div><span className="section-kicker">START WITH A QUESTION</span><h2>Big ideas start with a prompt.</h2><p>Pilih salah satu saran di bawah atau tulis pertanyaanmu sendiri.</p><div className="suggestion-grid">{[
        { icon: BookOpen, title: 'Help me learn', text: 'Buat rencana belajar AI untuk pemula.' },
        { icon: Code2, title: 'Build something', text: 'Sarankan proyek coding pertama untuk saya.' },
        { icon: Sparkles, title: 'Explore an idea', text: 'Bantu kembangkan ide startup teknologi.' },
      ].map(({ icon: Icon, title, text }) => <button key={title} className="suggestion-card" onClick={() => onSend(text)}><Icon size={17} /><span><strong>{title}</strong><small>{text}</small></span><ArrowRight size={15} /></button>)}</div></div> : <div className="chat-messages" aria-live="polite">{messages.map((message) => <article className={`chat-message ${message.role}`} key={message.id}><div className="message-avatar">{message.role === 'assistant' ? <BrainCircuit size={17} /> : 'Y'}</div><div className="message-body"><div className="message-meta"><strong>{message.role === 'assistant' ? 'XARVI AI · Demo' : 'You'}</strong><time>{new Date(message.createdAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}</time></div><p>{message.content}</p></div></article>)}{busy && <div className="typing-indicator"><span /><span /><span /> <small>Preparing demo response…</small></div>}</div>}
      <form className="composer" onSubmit={(event) => { event.preventDefault(); onSend(); }}><textarea aria-label="Tulis prompt" value={prompt} onChange={(event) => setPrompt(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter' && !event.shiftKey) { event.preventDefault(); onSend(); } }} placeholder="Message XARVI AI..." rows={2} maxLength={4000} /><div className="composer-bottom"><span><ShieldCheck size={14} /> Never share passwords or secret keys</span><div><span className="char-count">{prompt.length}/4000</span><button className="send-button" type="submit" disabled={!prompt.trim() || busy} aria-label="Kirim prompt"><Send size={17} /></button></div></div></form>
      <p className="composer-note">XARVI AI demo can make mistakes. Real AI integration is planned for the next milestone.</p>
    </div>
  );
}

function DashboardView({ messages, onOpenWorkspace, onClear }: { messages: ChatMessage[]; onOpenWorkspace: () => void; onClear: () => void }) {
  const userMessages = messages.filter((message) => message.role === 'user');
  return <div className="page-content generic-page"><div className="workspace-heading"><div><span className="section-kicker">OVERVIEW</span><h1>Your dashboard</h1><p>Ringkasan aktivitas di browser ini.</p></div><button className="secondary-button" onClick={onOpenWorkspace}><MessageSquare size={16} /> Open workspace</button></div><div className="stats-grid"><StatCard label="Local prompts" value={String(userMessages.length)} detail="Tersimpan di browser ini" icon={MessageSquare} /><StatCard label="Saved messages" value={String(messages.length)} detail="Pesan demo tersimpan" icon={Activity} /><StatCard label="AI API usage" value="0" detail="Belum ada request API" icon={Zap} /></div><section className="panel activity-panel"><div className="panel-heading"><div><h2>Recent activity</h2><p>Aktivitas yang tersimpan di perangkat ini.</p></div>{messages.length > 0 && <button className="quiet-button danger-text" onClick={onClear}><Trash2 size={15} /> Clear history</button>}</div>{userMessages.length === 0 ? <div className="empty-state"><div className="empty-state-icon"><Activity size={21} /></div><strong>No activity yet</strong><p>Mulai percakapan di AI Workspace untuk melihat aktivitas di sini.</p><button className="text-button" onClick={onOpenWorkspace}>Start a conversation <ArrowRight size={15} /></button></div> : <div className="activity-list">{[...userMessages].reverse().map((message) => <div className="activity-row" key={message.id}><div className="activity-icon"><MessageSquare size={16} /></div><div className="activity-copy"><strong>{message.content.slice(0, 90)}{message.content.length > 90 ? '…' : ''}</strong><small>{new Date(message.createdAt).toLocaleString('id-ID')}</small></div><span className="activity-tag">Demo</span></div>)}</div>}</section></div>;
}

function StatCard({ label, value, detail, icon: Icon }: { label: string; value: string; detail: string; icon: typeof Activity }) {
  return <div className="stat-card"><div className="stat-top"><span>{label}</span><span className="stat-icon"><Icon size={17} /></span></div><strong className="stat-value">{value}</strong><span className="stat-detail">{detail}</span></div>;
}

function SettingsView({ language, setLanguage, theme, setTheme, onClear }: { language: string; setLanguage: (value: string) => void; theme: string; setTheme: (value: string) => void; onClear: () => void }) {
  const [confirmClear, setConfirmClear] = useState(false);
  return <div className="page-content generic-page"><div className="workspace-heading"><div><span className="section-kicker">PREFERENCES</span><h1>Settings</h1><p>Atur preferensi workspace di browser ini.</p></div></div><section className="panel settings-panel"><div className="panel-heading"><div><h2>Appearance & language</h2><p>Preferensi disimpan untuk sesi browser ini.</p></div></div><div className="setting-row"><div className="setting-icon"><Sparkles size={18} /></div><div className="setting-copy"><strong>Color theme</strong><small>Pilih tampilan workspace.</small></div><select value={theme} onChange={(event) => setTheme(event.target.value)} aria-label="Color theme"><option>Dark</option><option>Light</option></select></div><div className="setting-row"><div className="setting-icon"><GlobeIcon /></div><div className="setting-copy"><strong>Language</strong><small>Bahasa antarmuka.</small></div><select value={language} onChange={(event) => setLanguage(event.target.value)} aria-label="Language"><option>Bahasa Indonesia</option><option>English</option></select></div></section><section className="panel settings-panel danger-panel"><div className="panel-heading"><div><h2>Local data</h2><p>Riwayat demo disimpan di localStorage browser.</p></div></div><div className="setting-row"><div className="setting-icon danger-icon"><Trash2 size={18} /></div><div className="setting-copy"><strong>Clear conversation history</strong><small>Hapus pesan demo yang tersimpan di perangkat ini.</small></div>{confirmClear ? <div className="confirm-actions"><button className="quiet-button" onClick={() => setConfirmClear(false)}>Cancel</button><button className="quiet-button danger-text" onClick={() => { onClear(); setConfirmClear(false); }}>Confirm</button></div> : <button className="secondary-button small-button" onClick={() => setConfirmClear(true)}>Clear data</button>}</div></section><div className="settings-footnote"><ShieldCheck size={16} /><span>Jangan masukkan password, API key, atau informasi rahasia ke workspace demo.</span></div></div>;
}

function GlobeIcon() {
  return <span className="globe-letter" aria-hidden="true">Aa</span>;
}

export default App;
