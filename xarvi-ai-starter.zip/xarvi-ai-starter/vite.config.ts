import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// GitHub Pages project sites use /<repository-name>/ as the base path.
// In local development and Codespaces, the base path stays at '/'.
const base = process.env.GITHUB_ACTIONS ? '/xarvi-ai/' : '/';

export default defineConfig({
  plugins: [react()],
  base,
});
