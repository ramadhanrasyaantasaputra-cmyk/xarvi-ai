# XARVI AI — Frontend MVP

A futuristic, mobile-first AI workspace starter built with React, TypeScript, Vite, and Lucide icons.

> **Important:** Milestone 1 is a frontend prototype. Chat replies are generated locally and are clearly marked as demo responses. No AI provider API is called and no API key is needed for this milestone.

## Features

- Futuristic dark interface with responsive mobile layout
- Landing page, AI Workspace, Dashboard, and Settings views
- Demo chat with local browser history
- AI tool prompt shortcuts
- Language and theme preferences in the current app session
- GitHub Pages deployment workflow

## Stack

- React 18
- TypeScript
- Vite
- Lucide React
- GitHub Actions / GitHub Pages

## Run in GitHub Codespaces

1. Open the repository in a Codespace.
2. Open the terminal inside Codespaces.
3. Run `npm install` the first time. This creates `package-lock.json`.
4. Run `npm run dev -- --host 0.0.0.0`.
5. Open the forwarded port 5173 in the browser preview.

Commit `package-lock.json` after it is generated. GitHub Actions uses `npm ci`, which requires this lockfile.

## Build and test

```bash
npm run build
```

This runs the TypeScript check and creates the production build in `dist/`. This README does not claim the build has passed in your environment; run it to verify.

## Deploy to GitHub Pages

1. Create a GitHub repository named exactly `xarvi-ai` if you want to use the included Vite base path unchanged.
2. Upload/commit all project files, including `.github/workflows/deploy.yml` and the generated `package-lock.json`.
3. Open repository **Settings → Pages**.
4. Under **Build and deployment**, select **GitHub Actions** as the source.
5. Push a commit to `main`, or manually run the workflow from the Actions tab.
6. Check the workflow result and open the Pages URL shown by GitHub.

The Vite base path is configured as `/xarvi-ai/` in GitHub Actions builds. If your repository has another name, update `vite.config.ts` accordingly.

## Next milestone: real AI API

Do not put provider API keys in frontend code, `VITE_*` variables, or a public repository. A real AI integration needs a backend or serverless endpoint that stores the secret in server-side environment variables, validates input, handles errors, and applies rate limits. Hosting the frontend on GitHub Pages does not provide a Node.js backend.

## License

No license has been selected yet. Add a license file if you decide how this project may be reused.
